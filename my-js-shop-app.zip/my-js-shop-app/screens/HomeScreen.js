import React, { useContext } from 'react';
import {
  View,
  Text,
  Button,
  FlatList,
  StyleSheet,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';

import { ItemContext } from '../context/ItemContext';
import { CartContext } from '../context/CartContext';
import { CurrencyContext } from '../context/CurrencyContext';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function HomeScreen() {
  const { items } = useContext(ItemContext);
  const { addToCart, cart } = useContext(CartContext);
  const { convert } = useContext(CurrencyContext);
  const navigation = useNavigation();

  const totalAmount = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <View style={styles.container}>
      {/* Header with cart total and icon + quantity badge */}
      <View style={styles.headerBar}>
        <Text style={styles.title}>🛍️ Shop Items</Text>
        <View style={styles.cartWrapper}>
          {totalItems > 0 && (
            <>
              <Text style={styles.cartTotal}>{convert(totalAmount)}</Text>
              <View style={styles.cartIconContainer}>
                <Icon
                  name="cart-outline"
                  size={28}
                  color="#000"
                  onPress={() => navigation.navigate('Cart')}
                />
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{totalItems}</Text>
                </View>
              </View>
            </>
          )}
          {totalItems === 0 && (
            <Icon
              name="cart-outline"
              size={28}
              color="#000"
              onPress={() => navigation.navigate('Cart')}
            />
          )}
        </View>
      </View>

      <FlatList
        data={items}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text style={styles.name}>{item.name}</Text>
            <Text>
              {convert(item.price)} —{' '}
              {item.quantity > 0 ? `${item.quantity} left` : 'Out of Stock'}
            </Text>
            <Button
              title="Add to Cart"
              onPress={() => addToCart(item)}
              disabled={item.quantity <= 0}
              color={item.quantity <= 0 ? 'gray' : '#2196F3'}
            />
          </View>
        )}
        ListEmptyComponent={<Text>No items in stock</Text>}
      />

      <Button
        title="🧹 Reset Items"
        onPress={async () => {
          await AsyncStorage.removeItem('items');
          alert('Items reset! Restart the app to reload defaults.');
        }}
        color="#f39c12"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  headerBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  cartWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cartTotal: {
    marginRight: 6,
    fontSize: 14,
    fontWeight: 'bold',
    color: '#2c3e50',
  },
  cartIconContainer: {
    position: 'relative',
  },
  badge: {
    position: 'absolute',
    right: -6,
    top: -4,
    backgroundColor: 'red',
    borderRadius: 10,
    paddingHorizontal: 5,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  item: {
    marginBottom: 12,
    padding: 10,
    borderWidth: 1,
    borderRadius: 8,
    borderColor: '#ccc',
  },
  name: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});
