import React, { useContext } from 'react';
import { View, Text, Button, FlatList, StyleSheet } from 'react-native';
import { CartContext } from '../context/CartContext';
import { CurrencyContext } from '../context/CurrencyContext';

export default function CartScreen() {
  const { cart, removeFromCart, clearCart, checkout, cartText } = useContext(CartContext);
  const { convert } = useContext(CurrencyContext);

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🛒 Cart</Text>
      <Text style={styles.title}>{cartText}</Text>
      <FlatList
        data={cart}
        keyExtractor={(item) => item.id.toString()}
        ListEmptyComponent={<Text style={styles.empty}>Your cart is empty.</Text>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.name}>{item.name}</Text>
            <Text>{convert(item.price)} × {item.quantity}</Text>
            <Text style={styles.total}>= {convert(item.price * item.quantity)}</Text>
            <Button title="Remove" color="crimson" onPress={() => removeFromCart(item.id)} />
          </View>
        )}
      />

      {cart.length > 0 && (
        <View style={styles.summary}>
          <Text style={styles.totalText}>Total: {convert(total)}</Text>
          <View style={styles.buttonRow}>
            <Button title="Checkout" onPress={checkout} />
            <View style={{ width: 10 }} />
            <Button title="🗑️ Empty Cart" color="#e74c3c" onPress={clearCart} />
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 22, marginBottom: 10 },
  card: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    padding: 12,
    marginBottom: 10,
  },
  name: { fontSize: 18, fontWeight: 'bold' },
  total: { marginTop: 5, fontWeight: 'bold' },
  empty: { textAlign: 'center', marginTop: 20, color: '#777' },
  summary: {
    marginTop: 20,
    borderTopWidth: 1,
    paddingTop: 10,
    borderColor: '#ccc',
  },
  totalText: { fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});
