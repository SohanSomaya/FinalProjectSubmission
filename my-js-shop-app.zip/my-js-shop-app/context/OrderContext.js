import React, { createContext, useContext } from 'react';
import { loadData, saveData } from '../utils/Storage';
import uuid from 'react-native-uuid';
import { UserContext } from './UserContext';

export const OrderContext = createContext();

export const OrderProvider = ({ children }) => {
  const { user } = useContext(UserContext);

  const addOrder = async (cart) => {
    if (!user) return;

    const key = `orders_${user.username}`;

    try {
      // Get existing orders (already parsed by loadData)
      const existing = await loadData(key);
      const previousOrders = Array.isArray(existing) ? existing : [];

      // Create new order
      const newOrder = {
        id: uuid.v4(),
        timestamp: Date.now(),
        items: cart,
      };

      const updatedOrders = [...previousOrders, newOrder];

      // ✅ Store as a string
      await saveData(key, JSON.stringify(updatedOrders));
    } catch (err) {
      console.error('Error saving order history:', err);
    }
  };

  return (
    <OrderContext.Provider value={{ addOrder }}>
      {children}
    </OrderContext.Provider>
  );
};
