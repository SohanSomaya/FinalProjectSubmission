import React, { createContext, useState, useContext, useEffect } from 'react';
import { Alert } from 'react-native';
import { loadData, saveData } from '../utils/Storage';
import { UserContext } from './UserContext';
import { ItemContext } from './ItemContext';
import { OrderContext } from './OrderContext';
import uuid from 'react-native-uuid';

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cartText, setCartText] = useState('Add Items!');
  const { user } = useContext(UserContext);
  const { updateItemQuantity } = useContext(ItemContext);
  const { addOrder } = useContext(OrderContext);
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const loadCart = async () => {
      if (user) {
        try {
          const stored = await loadData(`cart_${user.username}`);
          const parsed = stored ?? [];
          setCart(parsed);
        } catch (err) {
          console.error('Failed to load cart:', err);
        }
      }
    };
    loadCart();
  }, [user]);

  const saveCart = async (updatedCart) => {
    setCart(updatedCart);
    if (user) {
      try {
        await saveData(`cart_${user.username}`, JSON.stringify(updatedCart)); // ✅ Fix: stringify before saving
      } catch (err) {
        console.error('Failed to save cart:', err);
      }
    }
  };

  const addToCart = async (item) => {
    if (item.quantity <= 0) {
      Alert.alert('Out of Stock', 'This item is currently unavailable.');
      return;
    }

    const existing = cart.find((i) => i.id === item.id);
    const updatedCart = existing
      ? cart.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        )
      : [...cart, { ...item, quantity: 1 }];

    await updateItemQuantity(item.id, -1);
    await saveCart(updatedCart);
  };

  const removeFromCart = async (itemId) => {
    const target = cart.find((i) => i.id === itemId);
    if (!target) return;

    const updatedCart =
      target.quantity === 1
        ? cart.filter((i) => i.id !== itemId)
        : cart.map((i) =>
            i.id === itemId ? { ...i, quantity: i.quantity - 1 } : i
          );

    await updateItemQuantity(itemId, +1);
    await saveCart(updatedCart);
  };

  const clearCart = async () => {
    for (const item of cart) {
      await updateItemQuantity(item.id, item.quantity);
    }
    await saveCart([]);
  };

  const checkout = async () => {
    if (!user || cart.length === 0) {
      setCartText('Cart is empty!');
      return;
    }

    try {
      const purchaseKey = `purchases_${user.username}`;
      const existing = await loadData(purchaseKey);
      const previousPurchases = existing ?? [];

      const newPurchases = cart.map((item) => ({
        id: uuid.v4(),
        itemName: item.name,
        price: item.price * item.quantity,
        timestamp: Date.now(),
      }));

      const updatedPurchases = [...previousPurchases, ...newPurchases];
      await saveData(purchaseKey, JSON.stringify(updatedPurchases));

      await addOrder(cart, user);  // ✅ Pass user
      await saveCart([]);          // ✅ Clear cart (no restocking)
      setCart([]);
      setCartText('Thank you for your purchase!');
      setTimeout(() => {
        setCartText('Continue Shopping!');
      }, 2000);
    } catch (error) {
      console.error('Checkout error:', error);
      setCartText('Something went wrong! Try again later!');
    }
  };

  return (
    <CartContext.Provider
      value={{ cart, addToCart, removeFromCart, clearCart, checkout, cartText }}
    >
      {children}
    </CartContext.Provider>
  );
};
