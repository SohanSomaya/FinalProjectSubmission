import React, { createContext, useState, useEffect } from 'react';
import { loadData, saveData } from '../utils/Storage';

export const ItemContext = createContext();

export const ItemProvider = ({ children }) => {
  const [items, setItems] = useState([]);

  // context/ItemContext.js
useEffect(() => {
  const loadItems = async () => {
    const stored = await loadData('items');
    if (stored) {
      setItems(stored);
    } else {
      const initial = [
        { id: 1, name: 'Laptop', price: 999, quantity: 5 },
        { id: 2, name: 'Headphones', price: 199, quantity: 8 },
        { id: 3, name: 'Mouse', price: 49, quantity: 10 },
        { id: 4, name: 'Keyboard', price: 79, quantity: 7 },
        { id: 5, name: 'Monitor', price: 299, quantity: 3 },
        { id: 6, name: 'USB Cable', price: 15, quantity: 20 },
        { id: 7, name: 'Webcam', price: 89, quantity: 6 },
      ];
      setItems(initial);
      await saveData('items', initial);
    }
  };
  loadItems();
}, []);


  const updateItemQuantity = async (id, change) => {
    const updated = items.map((item) =>
      item.id === id
        ? { ...item, quantity: Math.max(0, item.quantity + change) }
        : item
    );
    setItems(updated);
    await saveData('items', updated);
  };

  const addNewItem = async (item) => {
    const updated = [...items, item];
    setItems(updated);
    await saveData('items', updated);
  };

  return (
    <ItemContext.Provider value={{ items, setItems, updateItemQuantity, addNewItem }}>
      {children}
    </ItemContext.Provider>
  );
};
